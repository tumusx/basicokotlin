fun main(){
    val bingo = listOf(8,6,8,9,4,5,2)
    var number = (1..34).random()

    println(number)
    println(number in bingo)

}